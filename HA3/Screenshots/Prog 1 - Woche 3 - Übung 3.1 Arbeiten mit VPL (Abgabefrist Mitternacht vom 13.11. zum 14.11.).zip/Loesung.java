/**
 *  Programmierung 1 - Pflichtabgabe
 *  Übung 3.1: Arbeiten mit VPL
 *  Studentin: Júlia da Silva Soares Vetter
 */

public class Loesung {
    public static void main(String[] args) {
// Hier Lösung der Aufgabe eintragen:
        System.out.println("Hello, world!"); // Einfach printen!
    }
}
